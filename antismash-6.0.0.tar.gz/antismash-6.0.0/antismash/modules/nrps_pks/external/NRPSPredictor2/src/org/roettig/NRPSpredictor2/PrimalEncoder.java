package org.roettig.NRPSpredictor2;

public interface PrimalEncoder
{
	double[] encode(String s);
}
